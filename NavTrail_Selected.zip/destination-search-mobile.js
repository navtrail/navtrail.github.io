import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, FlatList, Image, StyleSheet, TextInput, ActivityIndicator, Button, Alert } from 'react-native';

const API_URL = 'YOUR_FIREBASE_FUNCTION_URL';

const DestinationSearch = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [destinations, setDestinations] = useState([]);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [totalResults, setTotalResults] = useState(0);  //NEW
  const [error, setError] = useState(null);

  const fetchDestinations = useCallback(async () => {
    setLoading(true);
    setError(null); // Clear any previous errors
    try {
      const response = await fetch(
        `${API_URL}/destinationsSearch?q=${searchTerm}&page=${page}&pageSize=${pageSize}`
      );
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      const data = await response.json();
      setDestinations(data.results);
      setTotalResults(data.totalResults); //NEW
      console.log(data);
    } catch (err) {
      console.error('Error fetching destinations:', err);
      setError(err.message || 'Failed to fetch destinations.'); //Set proper error
      setDestinations([]);
      setTotalResults(0);
    } finally {
      setLoading(false);
    }
  }, [searchTerm, page, pageSize]);  //Dependency array now includes page and pageSize

  useEffect(() => {
    fetchDestinations();
  }, [fetchDestinations]); // use callback to prevent infinite loop

  const renderItem = useCallback(({ item }) => (
    <View style={styles.destinationItem}>
      <Image
        source={{ uri: item.imageUrl || 'https://via.placeholder.com/100' }}  // Placeholder image
        style={styles.destinationImage}
      />
      <View style={styles.destinationDetails}>
        <Text style={styles.destinationName}>{item.name}</Text>
        <Text style={styles.destinationDescription}>{item.description}</Text>
        <Text>Rating: {item.rating}</Text>
        <Text>Price: {item.priceRange || 'Not Available'}</Text>
      </View>
    </View>
  ), []);

  const keyExtractor = useCallback((item) => item.id.toString(), []);

  const handleLoadMore = () => {
      if (!loading && destinations.length < totalResults) {
          setPage(prevPage => prevPage + 1);  //Increment page only if needed
      }
  };

  const renderFooter = () => {
    if (!loading) return null;

    return (
      <View style={{ paddingVertical: 20, borderTopWidth: 1, borderColor: "#CED0CE" }}>
        <ActivityIndicator animating size="large" />
      </View>
    );
  };

  // useCallback to prevent re-renders
  const onSearchTermChange = useCallback((text) => {
    setSearchTerm(text);
    setPage(1); // Reset to page 1 on new search term
    setDestinations([]); //Clear current destionations
  }, []);

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.searchInput}
        placeholder="Search for destinations"
        value={searchTerm}
        onChangeText={onSearchTermChange}  //USE useCallback
      />

      {error && (
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>{error}</Text>
        </View>
      )}

      {loading && <ActivityIndicator size="large" color="#0000ff" />}  //Use ActivityIndicator

      <FlatList
        data={destinations}
        renderItem={renderItem}
        keyExtractor={keyExtractor}
        ListFooterComponent={renderFooter}
        onEndReached={handleLoadMore}
        onEndReachedThreshold={0.5}
        initialNumToRender={10} //Optimize loading
      />
    </View>
  );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 16,
    },
    searchInput: {
        height: 40,
        borderColor: 'gray',
        borderWidth: 1,
        borderRadius: 5,
        marginBottom: 10,
        paddingLeft: 8,
    },
    destinationItem: {
        flexDirection: 'row',
        marginBottom: 10,
        borderBottomWidth: 1,
        borderBottomColor: '#ddd',
        paddingBottom: 10,
    },
    destinationImage: {
        width: 100,
        height: 100,
        marginRight: 10,
    },
    destinationDetails: {
        flex: 1,
    },
    destinationName: {
        fontSize: 16,
        fontWeight: 'bold',
    },
    destinationDescription: {
        fontSize: 14,
        color: 'gray',
    },
        errorContainer: {
        backgroundColor: '#f8d7da',
        padding: 10,
        marginBottom: 10,
        borderRadius: 5,
    },
    errorText: {
        color: '#721c24',
    },
});

export default DestinationSearch;