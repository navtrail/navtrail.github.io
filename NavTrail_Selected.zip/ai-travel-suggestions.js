const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp();

const { OpenAI } = require("openai");

const mysql = require('mysql');
const dbConfig = {
    host: functions.config().mysql.host,
    user: functions.config().mysql.user,
    password: functions.config().mysql.password,
    database: functions.config().mysql.database,
};
const db = mysql.createPool(dbConfig);

// Ensure you set up the OPENAI_API_KEY environment variable in Firebase Functions
const openai = new OpenAI({
    apiKey: functions.config().openai.apikey,
});

exports.aiSuggestions = functions.https.onRequest(async (req, res) => {
    try {
        const destination = req.query.destination || '';
        const dates = req.query.dates || '';
        const budget = req.query.budget || '';
        const interests = req.query.interests || '';
        const userId = req.query.userId || '';

        // 1. Get User Preferences from MySQL
        let userPreferences = {};
        if (userId) {
            try {
                const userQuery = `SELECT TravelPreferences FROM Users WHERE UserID = ?`;
                const [userResult] = await db.promise().query(userQuery, [userId]);

                if (userResult.length > 0) {
                    userPreferences = JSON.parse(userResult[0].TravelPreferences);
                }

            } catch (error) {
                console.error('Failed to fetch or parse user preferences:', error);
                // Handle error gracefully (e.g., log and continue with default preferences)
                // Consider setting a default or empty set of preferences:
                userPreferences = {};
            }
        }

        // 2. Construct the Prompt for the AI Service:
        const prompt = `Suggest activities and a possible itinerary for a trip to ${destination} from ${dates} with a budget of ${budget} and interests in ${interests}.  Consider these user preferences: ${JSON.stringify(userPreferences)}. Provide specific place names and approximate costs. Limit the itinerary to 3 days. The response should be a JSON array, with each object representing a day. Each day object should have a key called "activities" which is a list of activity objects. Each activity should include the keys "Name", "Description", "ApproximateCost".  If the user likes "Historical Sites" then add Historical Sites to the intinerary. The activity's ApproximateCost should be in USD`;


        // 3. Call the AI Service (Rate Limiting Consideration):
        try {
            const completion = await openai.chat.completions.create({
                model: "gpt-3.5-turbo",
                messages: [{ role: "user", content: prompt }],
                temperature: 0.7,
            });

            const aiResponse = completion.choices[0].message.content;

            // 4. Process the AI Response (Parse JSON):
            let suggestions;
            try {
                suggestions = JSON.parse(aiResponse);
            } catch (parseError) {
                console.error('Error parsing AI response:', parseError);
                return res.status(500).send({ error: 'Failed to parse AI response. Raw AI Response: ' + aiResponse });
            }

            // 5. Enrich the Suggestions (Fetch Data from MySQL):
            // This uses Promise.all for concurrent execution and improved performance
            await Promise.all(suggestions.map(async (day) => {
                await Promise.all(day.activities.map(async (activity) => {
                    try {
                        // 5a. Fetch additional data from DB for activities
                        const activityName = activity.Name;  // Adjust this based on your response structure
                        const query = `SELECT ImageURL, Rating FROM Destinations WHERE Name LIKE ? LIMIT 1`; //Limit 1 for performance
                        const [results] = await db.promise().query(query, [`%${activityName}%`]);

                        if (results.length > 0) {
                            activity.imageUrl = results[0].ImageURL; // Image URL
                            activity.rating = results[0].Rating; // Place rating
                        }
                        else {
                            activity.imageUrl = "example.com/img.jpg" //Set Place holder data to avoid null values

                        }

                    } catch (dbError) {
                        console.error('DB Query Error:', dbError);
                    }
                }));
            }));
            // 6. Send the Response:
            res.status(200).send(suggestions);

        } catch (apiError) {
            // Handle API errors (e.g., rate limiting)
            console.error('AI Service API Error:', apiError);
            res.status(500).send({ error: 'Failed to get AI suggestions: ' + apiError.message });
        }

    } catch (error) {
        console.error('Error generating AI suggestions:', error);
        res.status(500).send({ error: 'Failed to generate AI suggestions: ' + error.message });
    }
});