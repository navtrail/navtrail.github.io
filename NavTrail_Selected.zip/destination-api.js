const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp();

const mysql = require('mysql');
const dbConfig = {
  host: functions.config().mysql.host,
  user: functions.config().mysql.user,
  password: functions.config().mysql.password,
  database: functions.config().mysql.database,
};
const db = mysql.createPool(dbConfig);

const express = require('express');  // Import express
const cors = require('cors');      // Import cors
const app = express();

// Enable CORS for all origins
app.use(cors());

// Security:  Input validation helper function
function sanitizeInput(input) {
  if (typeof input !== 'string') return ''; // Handle non-string inputs
  return input.replace(/[^a-zA-Z0-9\s]/g, ''); // Remove special characters
}

app.get('/destinations/search', async (req, res) => { // Changed to app.get
  try {
    // 1. Authentication (Optional):
    // (Example: Verify Firebase ID token. This will need your own middleware function)
    // if (!req.user) {
    //   return res.status(401).send({ error: 'Unauthorized' });
    // }
    // const userId = req.user.uid;

    // 2. Input Validation and Sanitization:
    const searchTerm = sanitizeInput(req.query.q || '');
    const category = sanitizeInput(req.query.category || '');
    const budget = sanitizeInput(req.query.budget || '');
    const sortBy = sanitizeInput(req.query.sortBy || 'Name');

    const page = parseInt(req.query.page) || 1;  //Default page 1
    const pageSize = parseInt(req.query.pageSize) || 10; //Default page size 10
    const offset = (page - 1) * pageSize;

    // Validate page and pageSize to prevent excessively large values
    if (page < 1 || pageSize < 1 || pageSize > 100) {
        return res.status(400).send({ error: 'Invalid page or pageSize' });
    }

    // 3. Build the SQL Query (Parameterized Queries!):
    let query = 'SELECT * FROM Destinations WHERE 1=1';
    const queryParams = []; // Array to hold parameters for parameterized query

    if (searchTerm) {
      query += ' AND Name LIKE ?';
      queryParams.push(`%${searchTerm}%`);
    }

    if (category) {
      query += ' AND Category = ?';
      queryParams.push(category);
    }

    if (budget) {
      query += ' AND PriceRange = ?';
      queryParams.push(budget);
    }

    query += ` ORDER BY ${sortBy} LIMIT ? OFFSET ?`;  // Pagination

    queryParams.push(pageSize, offset);

    // 4. Execute the Query (Using Parameterized Queries):
    db.query(query, queryParams, (error, results) => {
      if (error) {
        console.error('Error searching destinations:', error);
        res.status(500).send({ error: 'Failed to search destinations' });
        return;
      }

      // 5. Format the Results (As Before):
      const formattedResults = results.map(destination => ({
        id: destination.DestinationID,
        name: destination.Name,
        description: destination.Description,
        latitude: destination.Latitude,
        longitude: destination.Longitude,
        category: destination.Category,
        imageUrl: destination.ImageURL,
        rating: destination.Rating,
        priceRange: destination.PriceRange //Include price range
      }));

      // 6. Send the Response:
      res.status(200).send({
          page,
          pageSize,
          totalResults: formattedResults.length,
          results: formattedResults
      });
    });

  } catch (error) {
    console.error('Unexpected error:', error);
    res.status(500).send({ error: 'An unexpected error occurred.' });
  }
});

// Expose Express app as a single Cloud Function:
exports.destinationsSearch = functions.https.onRequest(app);